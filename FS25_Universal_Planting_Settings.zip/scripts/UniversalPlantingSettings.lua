UniversalPlantingSettings = {}

print("[UPS] UNIVERSAL PLANTING SETTINGS CARREGADO")

source(Utils.getFilename(
    "scripts/Multifruit.lua",
    g_currentModDirectory
))

source(Utils.getFilename(
    "scripts/DirectPlanting.lua",
    g_currentModDirectory
))

source(Utils.getFilename(
    "scripts/InstantRoll.lua",
    g_currentModDirectory
))

source(Utils.getFilename(
    "scripts/ShopSettings.lua",
    g_currentModDirectory
))

function UniversalPlantingSettings:loadMap(mapFilename)

    self.lastVehicle = nil

    print("[UPS] ------------------------------------------")
    print("[UPS] MODULOS DO UPS INICIALIZADOS")
    print("[UPS] ------------------------------------------")

end

function UniversalPlantingSettings:deleteMap()

    self.lastVehicle = nil

end

function UniversalPlantingSettings:update(dt)

    -- Os módulos possuem seus próprios listeners.
    -- O UPS principal apenas mantém o sistema central carregado.

end

function UniversalPlantingSettings:updateTick(dt)

end

function UniversalPlantingSettings:draw()

end

addModEventListener(UniversalPlantingSettings)