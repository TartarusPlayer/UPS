UniversalPlantingSettingsInstantRoll = {}

print("[UPS][ROLL] INSTANT ROLL CARREGADO")

function UniversalPlantingSettingsInstantRoll:disableRollingForAllFruits()

    if g_fruitTypeManager == nil then

        print("[UPS][ROLL] ERRO: g_fruitTypeManager NAO ENCONTRADO")

        return

    end

    local count = 0

    for fruitIndex, fruitType in pairs(g_fruitTypeManager.fruitTypes) do

        if fruitType ~= nil then

            fruitType.needsRolling = false

            count = count + 1

        end

    end

    print("[UPS][ROLL] ------------------------------------------")
    print("[UPS][ROLL] Culturas processadas: " .. tostring(count))
    print("[UPS][ROLL] >>> INSTANT ROLL ATIVADO!")
    print("[UPS][ROLL] ------------------------------------------")

end

local function onLoadMapFinished(mission, ...)

    print("[UPS][ROLL] ==========================================")
    print("[UPS][ROLL] MODULO INSTANT ROLL CARREGADO")
    print("[UPS][ROLL] ==========================================")

    UniversalPlantingSettingsInstantRoll:disableRollingForAllFruits()

end

FSBaseMission.loadMapFinished = Utils.appendedFunction(
    FSBaseMission.loadMapFinished,
    onLoadMapFinished
)