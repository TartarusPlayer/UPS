UniversalPlantingSettingsDirectPlanting = {}

function UniversalPlantingSettingsDirectPlanting:loadMap()

    print("[UPS][DIRECT] ==========================================")
    print("[UPS][DIRECT] MODULO DIRECT PLANTING CARREGADO")
    print("[UPS][DIRECT] ==========================================")

    self.lastPlanter = nil

end


function UniversalPlantingSettingsDirectPlanting:update(dt)

    if g_localPlayer == nil then
        return
    end

    local vehicle = g_localPlayer:getCurrentVehicle()

    if vehicle == nil then
        self.lastPlanter = nil
        return
    end

    local rootVehicle = vehicle.rootVehicle

    if rootVehicle == nil or rootVehicle.childVehicles == nil then
        return
    end

    local planter = nil

    for _, currentVehicle in ipairs(rootVehicle.childVehicles) do

        if currentVehicle.typeName == "sowingMachine"
        or currentVehicle.typeName == "fertilizingSowingMachine"
        or currentVehicle.typeName == "Planter"
        or currentVehicle.typeName == "fertilizingPlanter"
        or currentVehicle.typeName == "Planter SowingMachine" then

            planter = currentVehicle
            break

        end

    end

    if planter == nil then

        if self.lastPlanter ~= nil then

            print("[UPS][DIRECT] ------------------------------------------")
            print("[UPS][DIRECT] NENHUMA MAQUINA DE PLANTIO")

            self.lastPlanter = nil

        end

        return

    end

    if self.lastPlanter == planter then
        return
    end

    self.lastPlanter = planter

    if planter.spec_sowingMachine == nil then

        print("[UPS][DIRECT] ERRO: spec_sowingMachine NAO ENCONTRADO")

        return

    end


    local spec = planter.spec_sowingMachine

    print("[UPS][DIRECT] ------------------------------------------")
    print("[UPS][DIRECT] MAQUINA DE PLANTIO ENCONTRADA")

    if planter.getFullName ~= nil then

        print("[UPS][DIRECT] Nome: "
            .. tostring(planter:getFullName()))

    end

    print("[UPS][DIRECT] TypeName: "
        .. tostring(planter.typeName))

    print("[UPS][DIRECT] useDirectPlanting ANTES: "
        .. tostring(spec.useDirectPlanting))

    if spec.useDirectPlanting == false then

        spec.useDirectPlanting = true

        print("[UPS][DIRECT] >>> PLANTIO DIRETO ATIVADO!")

    elseif spec.useDirectPlanting == true then

        print("[UPS][DIRECT] >>> PLANTIO DIRETO JA ESTAVA ATIVADO!")

    else

        print("[UPS][DIRECT] useDirectPlanting NAO ENCONTRADO")

    end

    print("[UPS][DIRECT] useDirectPlanting DEPOIS: "
        .. tostring(spec.useDirectPlanting))

    print("[UPS][DIRECT] ------------------------------------------")

end

addModEventListener(UniversalPlantingSettingsDirectPlanting)