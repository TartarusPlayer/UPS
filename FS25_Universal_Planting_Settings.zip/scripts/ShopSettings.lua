UniversalPlantingSettingsShop = {}

print("[UPS][SHOP] SHOP SETTINGS CARREGADO")

local CONFIG_MULTIFRUIT      = "upsMultifruit"
local CONFIG_DIRECT_PLANTING = "upsDirectPlanting"
local CONFIG_INSTANT_ROLL    = "upsInstantRoll"

local PRICE_MULTIFRUIT      = 45000
local PRICE_DIRECT_PLANTING = 35000
local PRICE_INSTANT_ROLL    = 20000

if g_vehicleConfigurationManager.configurations[CONFIG_MULTIFRUIT] == nil then

    g_vehicleConfigurationManager:addConfigurationType(
        CONFIG_MULTIFRUIT,
        "Multifruit",
        CONFIG_MULTIFRUIT,
        VehicleConfigurationItem
    )

end

if g_vehicleConfigurationManager.configurations[CONFIG_DIRECT_PLANTING] == nil then

    g_vehicleConfigurationManager:addConfigurationType(
        CONFIG_DIRECT_PLANTING,
        "Direct Planting",
        CONFIG_DIRECT_PLANTING,
        VehicleConfigurationItem
    )

end

if g_vehicleConfigurationManager.configurations[CONFIG_INSTANT_ROLL] == nil then

    g_vehicleConfigurationManager:addConfigurationType(
        CONFIG_INSTANT_ROLL,
        "Instant Roll",
        CONFIG_INSTANT_ROLL,
        VehicleConfigurationItem
    )

end

local function createConfigurationItem(
    configurationName,
    index,
    name,
    price,
    isDefault
)

    local configurationDesc =
        g_vehicleConfigurationManager.configurations[
            configurationName
        ]

    if configurationDesc == nil then

        print(
            "[UPS][SHOP] ERRO: configuracao nao encontrada: "
            .. tostring(configurationName)
        )

        return nil

    end

    local item =
        configurationDesc.itemClass.new(configurationName)

    item:setIndex(index)

    item.name = name

    item.price = price

    item.isDefault = isDefault

    return item

end

local function isPlantingMachine(xmlFile)

    if xmlFile == nil then
        return false
    end

    -- SEMEADEIRA
    if xmlFile:hasProperty("vehicle.sowingMachine") then
        return true
    end

    -- SEMEADEIRA COM FERTILIZANTE
    if xmlFile:hasProperty("vehicle.fertilizingSowingMachine") then
        return true
    end

    -- PLANTADEIRA
    if xmlFile:hasProperty("vehicle.planter") then
        return true
    end

    -- PLANTADEIRA COM FERTILIZANTE
    if xmlFile:hasProperty("vehicle.fertilizingPlanter") then
        return true
    end

    return false

end

local function addUPSConfigurations(
    manager,
    superFunc,
    xmlFile,
    key,
    baseDir,
    customEnvironment,
    isMod,
    storeItem
)
    local configurations, defaultConfigurationIds =
        superFunc(
            manager,
            xmlFile,
            key,
            baseDir,
            customEnvironment,
            isMod,
            storeItem
        )

    if storeItem == nil then
        return configurations, defaultConfigurationIds
    end

    if configurations == nil then
        configurations = {}
    end

    if isPlantingMachine(xmlFile) then

        if configurations[CONFIG_MULTIFRUIT] == nil then

            configurations[CONFIG_MULTIFRUIT] = {}

            -- PADRÃO
            local standard =
                createConfigurationItem(
                    CONFIG_MULTIFRUIT,
                    1,
                    "Padrão",
                    0,
                    true
                )

            -- MULTIFRUIT
            local multifruit =
                createConfigurationItem(
                    CONFIG_MULTIFRUIT,
                    2,
                    "Multifruit",
                    PRICE_MULTIFRUIT,
                    false
                )

            if standard ~= nil then
                configurations[CONFIG_MULTIFRUIT][1] = standard
            end

            if multifruit ~= nil then
                configurations[CONFIG_MULTIFRUIT][2] = multifruit
            end

            if defaultConfigurationIds ~= nil then

                defaultConfigurationIds[CONFIG_MULTIFRUIT] = 1

            end

            print(
                "[UPS][SHOP] Multifruit adicionado - $"
                .. tostring(PRICE_MULTIFRUIT)
            )

        end

        if configurations[CONFIG_DIRECT_PLANTING] == nil then

            configurations[CONFIG_DIRECT_PLANTING] = {}

            -- PADRÃO
            local standard =
                createConfigurationItem(
                    CONFIG_DIRECT_PLANTING,
                    1,
                    "Padrão",
                    0,
                    true
                )

            -- DIRECT PLANTING
            local direct =
                createConfigurationItem(
                    CONFIG_DIRECT_PLANTING,
                    2,
                    "Plantio Direto",
                    PRICE_DIRECT_PLANTING,
                    false
                )

            if standard ~= nil then
                configurations[CONFIG_DIRECT_PLANTING][1] =
                    standard
            end

            if direct ~= nil then
                configurations[CONFIG_DIRECT_PLANTING][2] =
                    direct
            end

            if defaultConfigurationIds ~= nil then

                defaultConfigurationIds[CONFIG_DIRECT_PLANTING] = 1

            end

            print(
                "[UPS][SHOP] Direct Planting adicionado - $"
                .. tostring(PRICE_DIRECT_PLANTING)
            )

        end

    end

    if configurations[CONFIG_INSTANT_ROLL] == nil then

        configurations[CONFIG_INSTANT_ROLL] = {}

        -- PADRÃO
        local standard =
            createConfigurationItem(
                CONFIG_INSTANT_ROLL,
                1,
                "Normal",
                0,
                true
            )

        -- INSTANT ROLL
        local instantRoll =
            createConfigurationItem(
                CONFIG_INSTANT_ROLL,
                2,
                "Instant Roll",
                PRICE_INSTANT_ROLL,
                false
            )

        if standard ~= nil then
            configurations[CONFIG_INSTANT_ROLL][1] = standard
        end

        if instantRoll ~= nil then
            configurations[CONFIG_INSTANT_ROLL][2] = instantRoll
        end

        if defaultConfigurationIds ~= nil then

            defaultConfigurationIds[CONFIG_INSTANT_ROLL] = 1

        end

        print(
            "[UPS][SHOP] Instant Roll adicionado - $"
            .. tostring(PRICE_INSTANT_ROLL)
        )

    end

    return configurations, defaultConfigurationIds

end

ConfigurationUtil.getConfigurationsFromXML =
    Utils.overwrittenFunction(
        ConfigurationUtil.getConfigurationsFromXML,
        addUPSConfigurations
    )

function UniversalPlantingSettingsShop:loadMap(mapFilename)

    print("[UPS][SHOP] ------------------------------------------")
    print("[UPS][SHOP] MODULO SHOP SETTINGS INICIALIZADO")
    print("[UPS][SHOP] ------------------------------------------")

end

function UniversalPlantingSettingsShop:deleteMap()

end

function UniversalPlantingSettingsShop:update(dt)

end

function UniversalPlantingSettingsShop:updateTick(dt)

end

function UniversalPlantingSettingsShop:draw()

end

addModEventListener(UniversalPlantingSettingsShop)