UniversalPlantingSettingsMultiFruit = {}

function UniversalPlantingSettingsMultiFruit:loadMap()

    print("[UPS][MULTIFRUIT] ==========================================")
    print("[UPS][MULTIFRUIT] MODULO MULTIFRUIT CARREGADO")
    print("[UPS][MULTIFRUIT] ==========================================")

end

function UniversalPlantingSettingsMultiFruit:update(dt)

    if g_localPlayer == nil then
        return
    end


    local vehicle = g_localPlayer:getCurrentVehicle()

    if vehicle == nil then

        self.lastPlanter = nil

        return

    end


    local rootVehicle = vehicle.rootVehicle

    if rootVehicle == nil or rootVehicle.childVehicles == nil then
        return
    end

    local planter = nil

    for _, currentVehicle in ipairs(rootVehicle.childVehicles) do

        if currentVehicle.typeName == "sowingMachine"
        or currentVehicle.typeName == "planter"
        or currentVehicle.typeName == "fertilizingSowingMachine"
        or currentVehicle.typeName == "fertilizingPlanter"
        or currentVehicle.typeName == "Planter"
        or currentVehicle.typeName == "Planter SowingMachine" then

            planter = currentVehicle

            break

        end

    end

    if planter == nil then

        if self.lastPlanter ~= nil then

            print("[UPS][MULTIFRUIT] ------------------------------------------")
            print("[UPS][MULTIFRUIT] NENHUMA MAQUINA DE PLANTIO")

            self.lastPlanter = nil

        end

        return

    end

    if self.lastPlanter == planter then
        return
    end

    self.lastPlanter = planter

    if planter.spec_sowingMachine == nil then

        print("[UPS][MULTIFRUIT] ERRO: spec_sowingMachine NAO ENCONTRADO")

        return

    end

    local spec = planter.spec_sowingMachine

    if spec.seeds == nil then

        print("[UPS][MULTIFRUIT] ERRO: tabela seeds NAO ENCONTRADA")

        return

    end

    print("[UPS][MULTIFRUIT] ------------------------------------------")
    print("[UPS][MULTIFRUIT] MAQUINA DE PLANTIO ENCONTRADA")

    if planter.getFullName ~= nil then

        print("[UPS][MULTIFRUIT] Nome: "
            .. tostring(planter:getFullName()))

    end

    print("[UPS][MULTIFRUIT] TypeName: "
        .. tostring(planter.typeName))



    local isFertilizing = false

    if planter.typeName == "fertilizingSowingMachine"
    or planter.typeName == "fertilizingPlanter" then

        isFertilizing = true

        print("[UPS][MULTIFRUIT] Tipo: FERTILIZANTE")
        print("[UPS][MULTIFRUIT] Grupo: SOWINGMACHINE + PLANTER")
        print("[UPS][MULTIFRUIT] Fertilizante: MANTER")

    elseif planter.typeName == "sowingMachine"
    or planter.typeName == "planter"
    or planter.typeName == "Planter"
    or planter.typeName == "Planter SowingMachine" then

        print("[UPS][MULTIFRUIT] Tipo: SEM FERTILIZANTE")
        print("[UPS][MULTIFRUIT] Grupo: SOWINGMACHINE + PLANTER")

    else

        print("[UPS][MULTIFRUIT] TIPO DESCONHECIDO")

    end

    local newSeeds = {}

    local seedExists = {}

    for _, fruitTypeIndex in ipairs(spec.seeds) do

        if not seedExists[fruitTypeIndex] then

            table.insert(newSeeds, fruitTypeIndex)

            seedExists[fruitTypeIndex] = true

        end

    end

    local sowingMachineSeeds = {

        1,   -- WHEAT
        2,   -- BARLEY
        4,   -- OAT
        3,   -- CANOLA
        10,  -- RICELONGGRAIN
        25,  -- OILSEEDRADISH
        24,  -- GRASS
        22,  -- PEA
        23,  -- SPINACH
        28,  -- TRITICALE
        27   -- ALFALFA

    }

    local planterSeeds = {

        5,   -- MAIZE
        14,  -- SORGHUM
        6,   -- SUNFLOWER
        7,   -- SOYBEAN
        11,  -- SUGARBEET
        13,  -- COTTON
        21,  -- GREENBEAN
        26   -- BLACKBEAN

    }

    print("[UPS][MULTIFRUIT] Adicionando culturas SOWINGMACHINE")

    for _, fruitTypeIndex in ipairs(sowingMachineSeeds) do

        if not seedExists[fruitTypeIndex] then

            table.insert(newSeeds, fruitTypeIndex)

            seedExists[fruitTypeIndex] = true

        end

    end

    print("[UPS][MULTIFRUIT] Adicionando culturas PLANTER")

    for _, fruitTypeIndex in ipairs(planterSeeds) do

        if not seedExists[fruitTypeIndex] then

            table.insert(newSeeds, fruitTypeIndex)

            seedExists[fruitTypeIndex] = true

        end

    end

    spec.seeds = newSeeds

    spec.allowsSeedChanging = true

    if isFertilizing then

        print("[UPS][MULTIFRUIT] fillUnitIndex original: "
            .. tostring(spec.fillUnitIndex))

        print("[UPS][MULTIFRUIT] fillUnit 2: PRESERVADO")

    end

    print("[UPS][MULTIFRUIT] >>> MULTIFRUIT ATIVADO!")

    print("[UPS][MULTIFRUIT] Culturas disponiveis: "
        .. tostring(#spec.seeds))

    for i, fruitTypeIndex in ipairs(spec.seeds) do

        local fruitName = "DESCONHECIDO"

        if g_fruitTypeManager ~= nil
        and g_fruitTypeManager.getFruitTypeByIndex ~= nil then

            local fruitType =
                g_fruitTypeManager:getFruitTypeByIndex(fruitTypeIndex)


            if fruitType ~= nil
            and fruitType.name ~= nil then

                fruitName = tostring(fruitType.name)

            end

        end

        print("[UPS][MULTIFRUIT]   ["
            .. tostring(i)
            .. "] "
            .. fruitName
            .. " (ID "
            .. tostring(fruitTypeIndex)
            .. ")")

    end

    print("[UPS][MULTIFRUIT] ------------------------------------------")

end

addModEventListener(UniversalPlantingSettingsMultiFruit)